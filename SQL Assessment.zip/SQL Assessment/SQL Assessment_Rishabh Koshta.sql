--a.Write a script to create the Employees table.
CREATE TABLE CostCentre
( 
  costCentreID	INT			PRIMARY KEY,
  name			VARCHAR(50) ,
  accountNo		VARCHAR(50) 
);
GO
INSERT INTO CostCentre(costCentreID,name,accountNo)VALUES(1,'APAC' ,'001APAC101010')  ;
INSERT INTO CostCentre(costCentreID,name,accountNo)VALUES(2,'EMEA' ,'002EMEA111111')  ;
INSERT INTO CostCentre(costCentreID,name,accountNo)VALUES(3,'LATAM','003LATAM121212') ;
INSERT INTO CostCentre(costCentreID,name,accountNo)VALUES(4,'NAF'  ,'004NAF131313')	  ;
INSERT INTO CostCentre(costCentreID,name,accountNo)VALUES(5,'MEA'  ,'005MEA141414')	  ;
INSERT INTO CostCentre(costCentreID,name,accountNo)VALUES(6,'EU'   ,'006EU151515')	  ;
INSERT INTO CostCentre(costCentreID,name,accountNo)VALUES(7,'US'   ,'007US161616')	  ;


CREATE TABLE Department
( 
  departmentID	INT			  IDENTITY NOT NULL         PRIMARY KEY,
  name			VARCHAR(50)			   NOT NULL,
  costCentreID	INT,
  CONSTRAINT fk_costCentreID FOREIGN KEY (costCentreID) REFERENCES CostCentre (costCentreID) 
);

GO
INSERT INTO Department(name,costCentreID)VALUES('ACCOUNTING',1);
INSERT INTO Department(name,costCentreID)VALUES('OPERATIONS',2);
INSERT INTO Department(name,costCentreID)VALUES('RESEARCH',3);
INSERT INTO Department(name,costCentreID)VALUES('SALES',4);
INSERT INTO Department(name,costCentreID)VALUES('HR',5);
INSERT INTO Department(name,costCentreID)VALUES('FINANCE',6);

CREATE TABLE salaryLevel
( 
  salaryLevelID		 INT        NOT NULL               PRIMARY KEY,
  amount			 DECIMAL(7,2),
  increasePercetage  SMALLINT,
 );

GO
INSERT INTO salaryLevel(salaryLevelID,amount,increasePercetage)VALUES(1,30000.00,40);
INSERT INTO salaryLevel(salaryLevelID,amount,increasePercetage)VALUES(2,40000.00,30);
INSERT INTO salaryLevel(salaryLevelID,amount,increasePercetage)VALUES(3,50000.00,20);
INSERT INTO salaryLevel(salaryLevelID,amount,increasePercetage)VALUES(4,60000.00,10);
INSERT INTO salaryLevel(salaryLevelID,amount,increasePercetage)VALUES(5,70000.00,5);

CREATE TABLE Employees
( 
  employeeNo	INT IDENTITY	NOT NULL	            PRIMARY KEY,
  lastName		VARCHAR(50)		NOT NULL,
  firstName		VARCHAR(50)		NOT NULL, 
  gender		CHAR   (1)		NOT NULL,
  IDNumber		VARCHAR(20)		NOT NULL,
  salaryLevelID INT,
  departmentID	INT,
  CONSTRAINT fk_departmentID  FOREIGN KEY (departmentID) REFERENCES Department  (departmentID) 
  );
GO
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Ram'     ,'Iyer'   ,'M','AM001' ,1,1);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Ramesh'  ,'Soni'   ,'M','AM002' ,2,1);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Prashi'  ,'Tiwari' ,'F','AM003' ,3,2);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Rajesh'  ,'Yadav'  ,'M','AM004' ,4,2);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Prateek' ,'Pandey' ,'M','AM005' ,5,3);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Rishabh' ,'Gupta'  ,'M','AM006' ,1,3);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Pratibha','Patel'  ,'F','AM007' ,2,3);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Swarnima','Singh'  ,'M','AM008' ,3,4);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Prakash' ,'Gupta'  ,'M','AM009' ,1,5);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Swati'   ,'Patel'  ,'F','AM0010',2,6);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Suresh'  ,'Kumar'  ,'M','AM0011',5,6);
 INSERT INTO Employees(lastName,firstName,gender,IDNumber,salaryLevelID,departmentID)VALUES('Sarita'  ,'Koshti' ,'F','AM0012',10,6);
 
------------------------------------------------------------------------------------------------------------------------------------------
--b.	Write a script to alter the Employees table to increase the length of the 
------------------------------------------------------------------------------------------------------------------------------------------
 
ALTER TABLE   Employees
ALTER COLUMN  lastName varchar(60) ;

--------------------------------------------------------------------------------------------------------------------------------------------
--c. Create a stored procedure that takes in a parameter of a Department Name and returns all the employees� details for the department. 
--If no department name is passed in, return all the employees.
--------------------------------------------------------------------------------------------------------------------------------------------
GO
CREATE PROCEDURE sp_GetEmployeeDetails
                 @deptName varchar(50) 
AS
        if(@deptName IS NULL)
               (SELECT employeeNo	
                      ,lastName		
                      ,firstName		
                      ,gender		
                      ,IDNumber		
                      ,salaryLevelID 
                      ,departmentID	
                  FROM Employees)		  
        else(
              SELECT emp.employeeNo	
                    ,emp.lastName		
                    ,emp.firstName		
                    ,emp.gender		
                    ,emp.IDNumber		
                    ,emp.salaryLevelID 
                    ,emp.departmentID
        			,dept.name	
              FROM Employees emp
        	  LEFT JOIN Department dept
        	  ON emp.departmentID=dept.departmentID
              WHERE dept.name = @deptName
        )

-----------------------------------------------------------------------------------------------------------------------------------
--d. Create a script that returns each department name and the number of employees in each department.
-------------------------------------------------------------------------------------------------------------------------------------
    SELECT dept.NAME ,COUNT(*) as [Numberof Employees] 
      FROM Employees emp
INNER JOIN Department dept
        ON emp.departmentID = dept.departmentID 
  GROUP BY dept.name

  GO

----------------------------------------------------------------------------------------------------------------
--e. Create a script that filters by department name and returns the number of Males and females in the department
-----------------------------------------------------------------------------------------------------------------
      SELECT dept.NAME ,emp.gender, COUNT(*) as GenderCount
      FROM Employees emp
INNER JOIN Department dept
        ON emp.departmentID = dept.departmentID 
  GROUP BY emp.gender,dept.NAME 

  -----------------------------------------------------------------------------------------------------------------
--f.Create a script that filters by [employNo] and returns the salary amount as well as the department name.
---------------------------------------------------------------------------------------------------------------------
              SELECT emp.employeeNo	
                    ,emp.lastName		
                    ,emp.firstName		              
        			,dept.name	
					,sal.amount
              FROM Employees emp  
			  JOIN Department dept 
			  ON emp.departmentID=dept.departmentID
			  JOIN salaryLevel sal
			  ON EMP.salaryLevelID=sal.salaryLevelID

-----------------------------------------------------------------------------------------------------------------------------		 
--g.Assuming that the relationship between Employees and [salaryLevel] does not exist, create a script that returns all the employees
 --     that have a [salarylevelID] that is not in the Salary level table.
 ------------------------------------------------------------------------------------------------------------------------------
        SELECT emp.employeeNo	
                ,emp.lastName		
                ,emp.firstName
				,emp.salaryLevelID		              
				,sal.amount
            FROM Employees emp  
			Left join salaryLevel sal
			on emp.salaryLevelID = sal.salaryLevelID 
            where sal.salaryLevelID IS NULL
